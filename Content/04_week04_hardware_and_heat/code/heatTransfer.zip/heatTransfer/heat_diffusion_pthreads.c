/*
 * heat_diffusion_pthreads.c
 *
 * Shared-memory (Pthreads) implementation of the Heat Diffusion case study.
 * See Heat_Diffusion_Case_Study_Spec.md for the full physical model.
 *
 * Update rule (Jacobi, double-buffered):
 *   new[i][j] = 0.25 * (old[i-1][j] + old[i+1][j] + old[i][j-1] + old[i][j+1])
 *
 * Fixed cells (never updated):
 *   - Outer boundary ring: COLD (0.0)
 *   - Centered K x K block: HOT (1.0)  <- the "candle under the plate"
 *
 * Decomposition: contiguous row-blocks across threads (no halo needed --
 * shared address space means every thread can read any row of the old grid,
 * unlike the MPI version later, which will need one).
 *
 * Synchronization: two barriers per iteration, no locks.
 *   Barrier 1: all threads finish writing their row-block of `next_grid` and
 *              their own slot of thread_max_diff[] (disjoint writes -> no
 *              lock needed).
 *   [thread 0 only, single-threaded section]: reduce thread_max_diff[] to a
 *              global max, decide convergence, swap cur/next_grid, optionally
 *              dump a frame.
 *   Barrier 2: all threads wait until thread 0's decision + swap are visible
 *              before starting the next iteration's reads.
 *
 * Because each new frame is computed entirely from the previous frame (Jacobi,
 * not Gauss-Seidel), the output is bit-identical regardless of thread count
 * or scheduling -- the barriers exist to prevent a fast thread from reading a
 * neighbor row mid-write, not to fix a numerical race in any single cell.
 *
 * Output: one binary PGM (P5) frame every --frame-stride iterations, written
 * to --outdir. Stitch into a video with the companion Python script.
 *
 * Build:   gcc -O2 -Wall -pthread -lm -o heat_diffusion heat_diffusion_pthreads.c
 * Run:     ./heat_diffusion [N] [threads] [K] [epsilon] [max_iters] [frame_stride] [outdir]
 *
 * Frozen case-study parameters (see spec doc), used as defaults below:
 *   N=514 (512x512 updatable interior -- divides cleanly by 1/2/4/8/16 for
 *          the MPI/Warp units later), K=96, epsilon=1e-4 (~2200 iterations,
 *          under 2 sec on 4 threads), frame_stride=20 (~110 frames).
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <pthread.h>

/* ---- Globals shared across threads, kept explicit on purpose: this is a
 * teaching example, not production code, so state should be visible, not
 * hidden inside structs. ---- */

static int N;                    /* grid is N x N */
static int NUM_THREADS;
static int HOT_LO, HOT_HI;       /* hot block occupies [HOT_LO, HOT_HI) x [HOT_LO, HOT_HI) */
static double EPSILON;
static int MAX_ITERS;
static int FRAME_STRIDE;
static char OUTDIR[512];

static double *cur;               /* current grid: read-only during a step */
static double *next_grid;         /* grid being written during a step */
static double *thread_max_diff;   /* one slot per thread -- no lock needed */

static pthread_barrier_t barrier1;
static pthread_barrier_t barrier2;

static volatile int converged = 0;
static int iteration = 0;         /* shared, but only thread 0 ever writes it */

#define IDX(i, j) ((i) * N + (j))

static int is_fixed(int i, int j) {
    if (i == 0 || i == N - 1 || j == 0 || j == N - 1) return 1;           /* boundary */
    if (i >= HOT_LO && i < HOT_HI && j >= HOT_LO && j < HOT_HI) return 1; /* hot block */
    return 0;
}

static void init_grid(double *g) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (i == 0 || i == N - 1 || j == 0 || j == N - 1) {
                g[IDX(i, j)] = 0.0;   /* cold boundary */
            } else if (i >= HOT_LO && i < HOT_HI && j >= HOT_LO && j < HOT_HI) {
                g[IDX(i, j)] = 1.0;   /* hot block */
            } else {
                g[IDX(i, j)] = 0.0;   /* plate starts cold everywhere else */
            }
        }
    }
}

static void write_pgm_frame(const double *g, int frame_num) {
    char path[600];
    snprintf(path, sizeof(path), "%s/frame_%05d.pgm", OUTDIR, frame_num);
    FILE *f = fopen(path, "wb");
    if (!f) {
        fprintf(stderr, "warning: could not open %s for writing\n", path);
        return;
    }
    fprintf(f, "P5\n%d %d\n255\n", N, N);
    unsigned char *row = malloc((size_t)N);
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            double v = g[IDX(i, j)];
            if (v < 0.0) v = 0.0;
            if (v > 1.0) v = 1.0;
            row[j] = (unsigned char)(v * 255.0 + 0.5);
        }
        fwrite(row, 1, (size_t)N, f);
    }
    free(row);
    fclose(f);
}

typedef struct {
    int thread_id;
    int row_start;   /* inclusive: first updatable row owned by this thread */
    int row_end;     /* exclusive */
} thread_arg_t;

static void *worker(void *arg) {
    thread_arg_t *targ = (thread_arg_t *)arg;
    int tid = targ->thread_id;

    while (1) {
        /* --- compute phase: write this thread's row-block of next_grid --- */
        double local_max = 0.0;
        for (int i = targ->row_start; i < targ->row_end; i++) {
            for (int j = 1; j < N - 1; j++) {
                if (is_fixed(i, j)) {
                    next_grid[IDX(i, j)] = cur[IDX(i, j)];  /* fixed cells never change */
                    continue;
                }
                double val = 0.25 * (cur[IDX(i - 1, j)] + cur[IDX(i + 1, j)] +
                                      cur[IDX(i, j - 1)] + cur[IDX(i, j + 1)]);
                next_grid[IDX(i, j)] = val;
                double diff = fabs(val - cur[IDX(i, j)]);
                if (diff > local_max) local_max = diff;
            }
        }
        thread_max_diff[tid] = local_max;  /* own slot only -- no lock needed */

        pthread_barrier_wait(&barrier1);

        /* --- single-threaded decision phase: thread 0 only --- */
        if (tid == 0) {
            double global_max = 0.0;
            for (int t = 0; t < NUM_THREADS; t++) {
                if (thread_max_diff[t] > global_max) global_max = thread_max_diff[t];
            }

            /* swap cur <-> next_grid so 'cur' is the freshly computed frame */
            double *tmp = cur;
            cur = next_grid;
            next_grid = tmp;

            if (iteration % FRAME_STRIDE == 0) {
                write_pgm_frame(cur, iteration / FRAME_STRIDE);
            }

            if (global_max < EPSILON || iteration >= MAX_ITERS - 1) {
                converged = 1;
            }
            iteration++;
        }

        pthread_barrier_wait(&barrier2);

        if (converged) break;
    }

    return NULL;
}

int main(int argc, char *argv[]) {
    /* defaults -- frozen values from the shared case-study spec, pinned
     * empirically (see spec doc's "Status" section for how these were chosen) */
    N            = (argc > 1) ? atoi(argv[1]) : 514;
    NUM_THREADS  = (argc > 2) ? atoi(argv[2]) : 4;
    int K        = (argc > 3) ? atoi(argv[3]) : 96;
    EPSILON      = (argc > 4) ? atof(argv[4]) : 1e-4;
    MAX_ITERS    = (argc > 5) ? atoi(argv[5]) : 50000;
    FRAME_STRIDE = (argc > 6) ? atoi(argv[6]) : 20;
    snprintf(OUTDIR, sizeof(OUTDIR), "%s", (argc > 7) ? argv[7] : "frames");

    if (N < 3) { fprintf(stderr, "N must be >= 3\n"); return 1; }
    if (NUM_THREADS < 1 || NUM_THREADS > N - 2) {
        fprintf(stderr, "NUM_THREADS must be between 1 and N-2 (updatable rows)\n");
        return 1;
    }

    HOT_LO = (N - K) / 2;
    HOT_HI = HOT_LO + K;
    if (HOT_LO <= 0 || HOT_HI >= N - 1) {
        fprintf(stderr, "hot block (K=%d) doesn't fit inside boundary for N=%d\n", K, N);
        return 1;
    }

    char cmd[600];
    snprintf(cmd, sizeof(cmd), "mkdir -p %s", OUTDIR);
    if (system(cmd) != 0) {
        fprintf(stderr, "warning: could not create output dir %s\n", OUTDIR);
    }

    cur = malloc(sizeof(double) * (size_t)N * (size_t)N);
    next_grid = malloc(sizeof(double) * (size_t)N * (size_t)N);
    thread_max_diff = malloc(sizeof(double) * (size_t)NUM_THREADS);
    if (!cur || !next_grid || !thread_max_diff) {
        fprintf(stderr, "allocation failure\n");
        return 1;
    }

    init_grid(cur);
    memcpy(next_grid, cur, sizeof(double) * (size_t)N * (size_t)N);

    pthread_barrier_init(&barrier1, NULL, (unsigned)NUM_THREADS);
    pthread_barrier_init(&barrier2, NULL, (unsigned)NUM_THREADS);

    pthread_t *threads = malloc(sizeof(pthread_t) * (size_t)NUM_THREADS);
    thread_arg_t *targs = malloc(sizeof(thread_arg_t) * (size_t)NUM_THREADS);

    /* row-block decomposition over updatable rows [1, N-2] */
    int updatable_rows = N - 2;
    int base = updatable_rows / NUM_THREADS;
    int rem  = updatable_rows % NUM_THREADS;
    int row = 1;
    for (int t = 0; t < NUM_THREADS; t++) {
        int rows_for_t = base + (t < rem ? 1 : 0);
        targs[t].thread_id = t;
        targs[t].row_start = row;
        targs[t].row_end   = row + rows_for_t;
        row += rows_for_t;
    }

    struct timespec t_start, t_end;
    clock_gettime(CLOCK_MONOTONIC, &t_start);

    for (int t = 0; t < NUM_THREADS; t++) {
        pthread_create(&threads[t], NULL, worker, &targs[t]);
    }
    for (int t = 0; t < NUM_THREADS; t++) {
        pthread_join(threads[t], NULL);
    }

    clock_gettime(CLOCK_MONOTONIC, &t_end);
    double elapsed = (double)(t_end.tv_sec - t_start.tv_sec) +
                      (double)(t_end.tv_nsec - t_start.tv_nsec) / 1e9;

    printf("N=%d threads=%d K=%d eps=%g -> %d iterations, %.3f sec, %d frames -> %s/\n",
           N, NUM_THREADS, K, EPSILON, iteration, elapsed, iteration / FRAME_STRIDE + 1, OUTDIR);

    pthread_barrier_destroy(&barrier1);
    pthread_barrier_destroy(&barrier2);
    free(cur);
    free(next_grid);
    free(thread_max_diff);
    free(threads);
    free(targs);

    return 0;
}
