import sys

import numpy as np
from PIL import Image

image = Image.open(sys.argv[1])

# summarize the image
print(image.format)
print(image.size)
print(image.mode)

# convert the image into a NumPy array
npData = np.asarray(image, dtype=np.float32)
print(npData.shape)

# rebuild an image from the array
outImage = Image.fromarray(np.uint8(npData))
print(outImage.mode)
print(outImage.size)

# save it - it should be identical to the input
outImage.save("out.png")
