import sys

import numpy as np
import warp as wp
from PIL import Image

# change this to "cuda" if you have an Nvidia GPU
device = "cpu"


@wp.kernel
def passthroughFilterGray(inputImage: wp.array2d(dtype=wp.float32),
                          outputImage: wp.array2d(dtype=wp.float32)):
    i, j = wp.tid()
    outputImage[i, j] = inputImage[i, j]


@wp.kernel
def passthroughFilterColour(inputImage: wp.array3d(dtype=wp.float32),
                            outputImage: wp.array3d(dtype=wp.float32)):
    i, j, k = wp.tid()
    outputImage[i, j, k] = inputImage[i, j, k]


image = Image.open(sys.argv[1])

# summarize the image
print(image.format)
print(image.size)
print(image.mode)

npInData = np.asarray(image, dtype=np.float32)
print(npInData.dtype)
print(npInData.shape)

inWarpImage = wp.array(npInData, dtype=wp.float32, device=device)
outWarpImage = wp.zeros_like(inWarpImage)

# grayscale is 2D, colour is 3D
if image.mode == "L":
    wp.launch(passthroughFilterGray, dim=npInData.shape,
              inputs=[inWarpImage, outWarpImage], device=device)
else:
    wp.launch(passthroughFilterColour, dim=npInData.shape,
              inputs=[inWarpImage, outWarpImage], device=device)

npOutData = outWarpImage.numpy()

# Clip the image, to keep output pixel values in the [0, 255] range
npOutData = np.uint8(np.clip(np.rint(npOutData), 0, 255))

# rebuild an image from the array
outImage = Image.fromarray(np.uint8(npOutData))
print(outImage.mode)
print(outImage.size)

outImage.save("out.png")
