import numpy as np
import warp as wp

numPoints = 1024

# change this to "cuda" if you have an Nvidia GPU
device = "cpu"

@wp.kernel
def length(points: wp.array(dtype=wp.vec3),
           lengths: wp.array(dtype=wp.float32)):
    tid = wp.tid()

    # distance of each point from the origin
    lengths[tid] = wp.length(points[tid])


points = wp.array(np.random.rand(numPoints, 3), dtype=wp.vec3, device=device)
lengths = wp.zeros(numPoints, dtype=wp.float32, device=device)

wp.launch(length, dim=numPoints, inputs=[points, lengths], device=device)

print(lengths)
