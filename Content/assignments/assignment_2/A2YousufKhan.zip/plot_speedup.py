import csv
import statistics

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rows = list(csv.DictReader(open("experiment.csv", newline="")))
serialMedian = statistics.median(
    float(r["TIME"]) for r in rows if r["program"] == "decryptSerial")

ps = [2, 3, 5]
speedups = [[serialMedian / float(r["TIME"]) for r in rows if r["p"] == str(p)]
            for p in ps]

fig, ax = plt.subplots(figsize=(7, 4.5))
ax.plot([1, 6], [1, 6], "k--", linewidth=1, label="Ideal, S(p) = p")
ax.plot([1, 6], [0, 5], "k:", linewidth=1.5, label="Ideal for p - 1 workers")
ax.boxplot(speedups, positions=ps, widths=0.35)
ax.set_xlim(1, 6)
ax.set_ylim(0, 6)
ax.set_xticks(ps)
ax.set_xticklabels([str(p) for p in ps])
ax.set_xlabel("Processes p")
ax.set_ylabel("Speedup S(p)")
ax.grid(True, alpha=0.3)
ax.legend(loc="upper left")
fig.tight_layout()
fig.savefig("speedup.png", dpi=200)
