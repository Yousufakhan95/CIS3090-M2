#include "encrypt.h"
#include <string.h>
#include <ctype.h>

void encryptPlainText(const char *phrase, const char *letterSet, const char *key, char *cipherText) {
    for (int i = 0; phrase[i] != '\0'; i++) {
        if (isspace((unsigned char)phrase[i])) {
            cipherText[i] = phrase[i];
            continue;
        }

        int pos = -1;
        for (int j = 0; letterSet[j] != '\0'; j++) {
            if (letterSet[j] == phrase[i]) {
                pos = j;
                break;
            }
        }
        cipherText[i] = (pos >= 0) ? key[pos] : phrase[i];
    }
    cipherText[strlen(phrase)] = '\0';
}