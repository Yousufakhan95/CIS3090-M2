#include "encrypt.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>

void makeKey(const char *letterSet, char *key) {
    strcpy(key, letterSet);
    int len = strlen(key);
    if (len <= 1) {
        return;
    }

    srand((unsigned)time(NULL));

    for (int i = len - 1; i > 0; i--) {
        int j = rand() % (i + 1);
        char tmp = key[i];
        key[i] = key[j];
        key[j] = tmp;
    }
}