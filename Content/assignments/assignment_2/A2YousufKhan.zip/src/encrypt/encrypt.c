#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "encrypt.h"

int main(int argc, char *argv[]) {
    if (argc != 2) {
        fprintf(stderr, "Usage: %s \"phrase to encrypt\"\n", argv[0]);
        return 1;
    }

    char *phrase = argv[1];
    char letterSet[27];
    char key[27];
    char *cipherText = malloc(strlen(phrase) + 1);
    if (cipherText == NULL) {
        fprintf(stderr, "malloc failed\n");
        return 1;
    }

    makeLetterSet(phrase, letterSet);
    makeKey(letterSet, key);
    encryptPlainText(phrase, letterSet, key, cipherText);

    printf("%s\n", cipherText);

    free(cipherText);
    return 0;
}