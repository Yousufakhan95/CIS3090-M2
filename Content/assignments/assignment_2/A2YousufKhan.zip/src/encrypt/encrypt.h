#ifndef ENCRYPT_H
#define ENCRYPT_H

void makeLetterSet(const char *phrase, char *letterSet);
void makeKey(const char *letterSet, char *key);
void encryptPlainText(const char *phrase, const char *letterSet, const char *key, char *cipherText);

#endif