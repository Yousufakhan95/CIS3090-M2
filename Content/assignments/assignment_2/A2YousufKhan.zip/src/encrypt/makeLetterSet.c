#include "encrypt.h"
#include <string.h>
#include <ctype.h>

void makeLetterSet(const char *phrase, char *letterSet) {
    int len = strlen(phrase);
    int seen[26] = {0};
    int setLen = 0;

    for (int i = 0; i < len; i++) {
        char c = phrase[i];
        if (!isalpha(c)) {
            continue;
        }
        c = tolower(c);
        int idx = c - 'a';
        if (!seen[idx]) {
            seen[idx] = 1;
            letterSet[setLen++] = c;
        }
    }
    letterSet[setLen] = '\0';
}
