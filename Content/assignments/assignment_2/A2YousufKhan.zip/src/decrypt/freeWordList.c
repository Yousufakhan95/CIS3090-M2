#include "decrypt.h"
#include <stdlib.h>

void freeWordList(WordList *words) {
    free(words->table);
    free(words->buffer);
    words->table = NULL;
    words->buffer = NULL;
    words->capacity = 0;
}
