#include "decryptParallel.h"
#include <mpi.h>

void runManager(char messages[][MAX_LINE], int count, int size,
                char results[][MAX_RESULTS][MAX_LINE], int *found) {
    int assigned[size];
    for (int i = 0; i < size; i++) {
        assigned[i] = -1;
    }

    int next = 0;
    int stopped = 0;
    while (stopped < size - 1) {
        int n;
        MPI_Status status;
        MPI_Recv(&n, 1, MPI_INT, MPI_ANY_SOURCE, TAG_REQUEST, MPI_COMM_WORLD, &status);
        int worker = status.MPI_SOURCE;

        int line = assigned[worker];
        if (line != -1) {
            found[line] = n;
            for (int r = 0; r < n; r++) {
                MPI_Recv(results[line][r], MAX_LINE, MPI_CHAR, worker, TAG_RESULT,
                         MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
        }

        if (next < count) {
            MPI_Send(messages[next], MAX_LINE, MPI_CHAR, worker, TAG_WORK, MPI_COMM_WORLD);
            assigned[worker] = next;
            next++;
        } else {
            char stop = 0;
            MPI_Send(&stop, 0, MPI_CHAR, worker, TAG_STOP, MPI_COMM_WORLD);
            assigned[worker] = -1;
            stopped++;
        }
    }
}
