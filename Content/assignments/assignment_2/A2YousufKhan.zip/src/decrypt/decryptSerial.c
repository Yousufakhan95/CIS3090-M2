#define _POSIX_C_SOURCE 199309L

#include "decrypt.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static char messages[MAX_MESSAGES][MAX_LINE];

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Usage: %s <batchFile> <wordList>\n", argv[0]);
        return 1;
    }

    long size;
    char *buffer = loadWordList(argv[2], &size);
    if (buffer == NULL) {
        fprintf(stderr, "Error: cannot read word list %s\n", argv[2]);
        return 1;
    }

    WordList words;
    if (buildWordList(buffer, size, &words) != 0) {
        fprintf(stderr, "Error: out of memory building word list\n");
        free(buffer);
        return 1;
    }

    int count = readBatch(argv[1], messages);
    if (count < 0) {
        fprintf(stderr, "Error: cannot read batch file %s\n", argv[1]);
        freeWordList(&words);
        return 1;
    }

    char (*results)[MAX_RESULTS][MAX_LINE] = malloc((count > 0 ? count : 1) * sizeof *results);
    int found[MAX_MESSAGES];
    if (results == NULL) {
        fprintf(stderr, "Error: out of memory\n");
        freeWordList(&words);
        return 1;
    }

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);

    for (int i = 0; i < count; i++) {
        decryptMessage(messages[i], &words, results[i], &found[i]);
    }

    clock_gettime(CLOCK_MONOTONIC, &end);
    double seconds = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    for (int i = 0; i < count; i++) {
        if (found[i] == 0) {
            printf("%d: NONE\n", i + 1);
        }
        for (int r = 0; r < found[i]; r++) {
            printf("%d: %s\n", i + 1, results[i][r]);
        }
    }
    fprintf(stderr, "TIME: %.3f\n", seconds);

    free(results);
    freeWordList(&words);
    return 0;
}
