#ifndef DECRYPT_H
#define DECRYPT_H

#define MAX_MESSAGES 100
#define MAX_LINE 256
#define MAX_RESULTS 1000

typedef struct {
    char *buffer;
    char **table;
    unsigned long capacity;
} WordList;

char *loadWordList(const char *path, long *size);
int buildWordList(char *buffer, long size, WordList *words);
unsigned long hashWord(const char *word, int length);
int wordInList(const WordList *words, const char *word, int length);
void freeWordList(WordList *words);
int readBatch(const char *path, char messages[][MAX_LINE]);
int nextPermutation(char *letters, int n);
int plaintextIsValid(const char *plaintext, const WordList *words);
long decryptMessage(const char *cipher, const WordList *words, char results[][MAX_LINE], int *found);

#endif
