#include "decrypt.h"
#include "encrypt.h"
#include <string.h>

long decryptMessage(const char *cipher, const WordList *words, char results[][MAX_LINE], int *found) {
    char letterSet[27];
    char key[27];
    char plaintext[MAX_LINE];

    makeLetterSet(cipher, letterSet);
    int n = strlen(letterSet);

    // sorted start so nextPermutation covers every key
    strcpy(key, letterSet);
    for (int i = 1; i < n; i++) {
        char c = key[i];
        int j = i - 1;
        while (j >= 0 && key[j] > c) {
            key[j + 1] = key[j];
            j--;
        }
        key[j + 1] = c;
    }

    long keys = 0;
    *found = 0;
    do {
        keys++;
        encryptPlainText(cipher, letterSet, key, plaintext);
        if (plaintextIsValid(plaintext, words) && *found < MAX_RESULTS) {
            strcpy(results[*found], plaintext);
            (*found)++;
        }
    } while (nextPermutation(key, n));

    return keys;
}
