#include "decrypt.h"

int nextPermutation(char *letters, int n) {
    int i = n - 2;
    while (i >= 0 && letters[i] >= letters[i + 1]) {
        i--;
    }
    if (i < 0) {
        return 0;
    }

    int j = n - 1;
    while (letters[j] <= letters[i]) {
        j--;
    }
    char tmp = letters[i];
    letters[i] = letters[j];
    letters[j] = tmp;

    for (int left = i + 1, right = n - 1; left < right; left++, right--) {
        tmp = letters[left];
        letters[left] = letters[right];
        letters[right] = tmp;
    }
    return 1;
}
