#include "decrypt.h"
#include <string.h>

unsigned long hashWord(const char *word, int length) {
    unsigned long hash = 2166136261UL;
    for (int i = 0; i < length; i++) {
        hash ^= (unsigned char)word[i];
        hash *= 16777619UL;
    }
    return hash;
}

int wordInList(const WordList *words, const char *word, int length) {
    unsigned long mask = words->capacity - 1;
    unsigned long slot = hashWord(word, length) & mask;

    while (words->table[slot] != NULL) {
        const char *entry = words->table[slot];
        if (strncmp(entry, word, length) == 0 && entry[length] == '\0') {
            return 1;
        }
        slot = (slot + 1) & mask;
    }
    return 0;
}
