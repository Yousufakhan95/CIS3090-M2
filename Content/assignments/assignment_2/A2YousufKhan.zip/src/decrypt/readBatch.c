#include "decrypt.h"
#include <stdio.h>
#include <string.h>

int readBatch(const char *path, char messages[][MAX_LINE]) {
    FILE *fp = fopen(path, "r");
    if (fp == NULL) {
        return -1;
    }

    int count = 0;
    while (count < MAX_MESSAGES && fgets(messages[count], MAX_LINE, fp) != NULL) {
        size_t len = strlen(messages[count]);
        if (len > 0 && messages[count][len - 1] == '\n') {
            messages[count][--len] = '\0';
            if (len > 0 && messages[count][len - 1] == '\r') {
                messages[count][--len] = '\0';
            }
        } else {
            /* Newline was not in this read: the line filled the buffer, or this is EOF. */
            if (len > 0 && messages[count][len - 1] == '\r') {
                messages[count][--len] = '\0';
            }
            int extra = fgetc(fp);
            while (extra != '\n' && extra != EOF) {
                extra = fgetc(fp);
            }
        }
        count++;
    }
    fclose(fp);

    while (count > 0 && messages[count - 1][0] == '\0') {
        count--;
    }
    return count;
}
