#ifndef DECRYPT_PARALLEL_H
#define DECRYPT_PARALLEL_H

#include "decrypt.h"

#define TAG_REQUEST 1
#define TAG_RESULT 2
#define TAG_WORK 3
#define TAG_STOP 4

int broadcastWordList(char **buffer, long *size, int rank);
void runManager(char messages[][MAX_LINE], int count, int size,
                char results[][MAX_RESULTS][MAX_LINE], int *found);
void runWorker(const WordList *words, int *messages, long *keys, double *busy);

#endif
