#include "decrypt.h"

int plaintextIsValid(const char *plaintext, const WordList *words) {
    const char *start = plaintext;
    for (const char *p = plaintext; ; p++) {
        if (*p == ' ' || *p == '\0') {
            if (!wordInList(words, start, p - start)) {
                return 0;
            }
            if (*p == '\0') {
                return 1;
            }
            start = p + 1;
        }
    }
}
