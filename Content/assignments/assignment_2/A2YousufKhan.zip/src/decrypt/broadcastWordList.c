#include "decryptParallel.h"
#include <mpi.h>
#include <stdlib.h>

int broadcastWordList(char **buffer, long *size, int rank) {
    MPI_Bcast(size, 1, MPI_LONG, 0, MPI_COMM_WORLD);

    if (rank != 0) {
        *buffer = malloc(*size + 1);
        if (*buffer == NULL) {
            return -1;
        }
    }
    MPI_Bcast(*buffer, (int)*size, MPI_CHAR, 0, MPI_COMM_WORLD);
    return 0;
}
