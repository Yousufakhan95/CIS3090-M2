#include "decrypt.h"
#include <stdio.h>
#include <stdlib.h>

char *loadWordList(const char *path, long *size) {
    FILE *fp = fopen(path, "rb");
    if (fp == NULL) {
        return NULL;
    }

    if (fseek(fp, 0, SEEK_END) != 0) {
        fclose(fp);
        return NULL;
    }
    long len = ftell(fp);
    if (len < 0) {
        fclose(fp);
        return NULL;
    }
    rewind(fp);

    char *buffer = malloc(len + 1);
    if (buffer == NULL) {
        fclose(fp);
        return NULL;
    }
    if ((long)fread(buffer, 1, len, fp) != len) {
        free(buffer);
        fclose(fp);
        return NULL;
    }
    fclose(fp);

    *size = len;
    return buffer;
}
