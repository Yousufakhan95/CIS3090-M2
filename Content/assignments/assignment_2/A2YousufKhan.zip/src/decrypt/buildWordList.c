#include "decrypt.h"
#include <stdlib.h>
#include <string.h>

int buildWordList(char *buffer, long size, WordList *words) {
    buffer[size] = '\0';

    long count = 0;
    for (long i = 0; i < size; i++) {
        if (buffer[i] == '\n' || buffer[i] == '\r') {
            buffer[i] = '\0';
        }
    }
    for (long i = 0; i < size; i++) {
        if (buffer[i] != '\0' && (i == 0 || buffer[i - 1] == '\0')) {
            count++;
        }
    }

    unsigned long capacity = 1;
    while (capacity < (unsigned long)count * 2 + 1) {
        capacity *= 2;
    }

    char **table = calloc(capacity, sizeof(char *));
    if (table == NULL) {
        return -1;
    }

    for (long i = 0; i < size; i++) {
        if (buffer[i] == '\0' || (i > 0 && buffer[i - 1] != '\0')) {
            continue;
        }
        char *word = &buffer[i];
        int length = strlen(word);
        unsigned long slot = hashWord(word, length) & (capacity - 1);
        while (table[slot] != NULL) {
            slot = (slot + 1) & (capacity - 1);
        }
        table[slot] = word;
    }

    words->buffer = buffer;
    words->table = table;
    words->capacity = capacity;
    return 0;
}
