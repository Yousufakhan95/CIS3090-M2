#include "decryptParallel.h"
#include "decrypt.h"
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

static char messages[MAX_MESSAGES][MAX_LINE];
static int found[MAX_MESSAGES];

int main(int argc, char *argv[]) {
    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (size < 2) {
        fprintf(stderr, "Error: %s needs at least 2 MPI processes\n", argv[0]);
        MPI_Finalize();
        return 1;
    }
    if (argc != 3) {
        if (rank == 0) {
            fprintf(stderr, "Usage: mpiexec -n <p> %s <batchFile> <wordList>\n", argv[0]);
        }
        MPI_Finalize();
        return 1;
    }

    long wordBytes = 0;
    char *buffer = NULL;
    int count = 0;
    char (*results)[MAX_RESULTS][MAX_LINE] = NULL;

    int failed = 0;
    if (rank == 0) {
        buffer = loadWordList(argv[2], &wordBytes);
        if (buffer == NULL) {
            fprintf(stderr, "Error: cannot read word list %s\n", argv[2]);
            failed = 1;
        } else {
            count = readBatch(argv[1], messages);
            if (count < 0) {
                fprintf(stderr, "Error: cannot read batch file %s\n", argv[1]);
                free(buffer);
                buffer = NULL;
                failed = 1;
            } else {
                results = malloc((count > 0 ? count : 1) * sizeof *results);
                if (results == NULL) {
                    fprintf(stderr, "Error: out of memory\n");
                    free(buffer);
                    buffer = NULL;
                    failed = 1;
                }
            }
        }
    }
    MPI_Bcast(&failed, 1, MPI_INT, 0, MPI_COMM_WORLD);
    if (failed) {
        MPI_Finalize();
        return 1;
    }

    MPI_Barrier(MPI_COMM_WORLD);
    double start = MPI_Wtime();

    if (broadcastWordList(&buffer, &wordBytes, rank) != 0) {
        fprintf(stderr, "Error: out of memory receiving word list\n");
        MPI_Abort(MPI_COMM_WORLD, 1);
    }

    int myMessages = 0;
    long myKeys = 0;
    double myBusy = 0.0;
    WordList words;

    if (rank == 0) {
        free(buffer);
        runManager(messages, count, size, results, found);
    } else {
        if (buildWordList(buffer, wordBytes, &words) != 0) {
            fprintf(stderr, "Error: out of memory building word list\n");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }
        runWorker(&words, &myMessages, &myKeys, &myBusy);
    }

    double elapsed = MPI_Wtime() - start;

    int allMessages[size];
    long allKeys[size];
    double allBusy[size];
    double maxElapsed = 0.0;
    MPI_Gather(&myMessages, 1, MPI_INT, allMessages, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Gather(&myKeys, 1, MPI_LONG, allKeys, 1, MPI_LONG, 0, MPI_COMM_WORLD);
    MPI_Gather(&myBusy, 1, MPI_DOUBLE, allBusy, 1, MPI_DOUBLE, 0, MPI_COMM_WORLD);
    MPI_Reduce(&elapsed, &maxElapsed, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);

    if (rank == 0) {
        for (int i = 0; i < count; i++) {
            if (found[i] == 0) {
                printf("%d: NONE\n", i + 1);
            }
            for (int r = 0; r < found[i]; r++) {
                printf("%d: %s\n", i + 1, results[i][r]);
            }
        }

        double busyMin = allBusy[1];
        double busyMax = allBusy[1];
        for (int r = 0; r < size; r++) {
            fprintf(stderr, "RANK: %d MESSAGES: %d KEYS: %ld BUSY: %.3f\n",
                    r, allMessages[r], allKeys[r], allBusy[r]);
            if (r > 0 && allBusy[r] < busyMin) {
                busyMin = allBusy[r];
            }
            if (r > 0 && allBusy[r] > busyMax) {
                busyMax = allBusy[r];
            }
        }
        fprintf(stderr, "BUSY_MIN: %.3f\n", busyMin);
        fprintf(stderr, "BUSY_MAX: %.3f\n", busyMax);
        fprintf(stderr, "TIME: %.3f\n", maxElapsed);

        free(results);
    } else {
        freeWordList(&words);
    }

    MPI_Finalize();
    return 0;
}
