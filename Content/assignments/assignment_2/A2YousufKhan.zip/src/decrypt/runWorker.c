#include "decryptParallel.h"
#include <mpi.h>

static char results[MAX_RESULTS][MAX_LINE];

void runWorker(const WordList *words, int *messages, long *keys, double *busy) {
    char cipher[MAX_LINE];
    int found = 0;
    *messages = 0;
    *keys = 0;
    *busy = 0.0;

    MPI_Send(&found, 1, MPI_INT, 0, TAG_REQUEST, MPI_COMM_WORLD);
    while (1) {
        MPI_Status status;
        MPI_Recv(cipher, MAX_LINE, MPI_CHAR, 0, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        if (status.MPI_TAG == TAG_STOP) {
            break;
        }

        double start = MPI_Wtime();
        *keys += decryptMessage(cipher, words, results, &found);
        *busy += MPI_Wtime() - start;
        (*messages)++;

        MPI_Send(&found, 1, MPI_INT, 0, TAG_REQUEST, MPI_COMM_WORLD);
        for (int r = 0; r < found; r++) {
            MPI_Send(results[r], MAX_LINE, MPI_CHAR, 0, TAG_RESULT, MPI_COMM_WORLD);
        }
    }
}
