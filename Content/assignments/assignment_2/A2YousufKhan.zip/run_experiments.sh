#!/bin/bash
# Run the Assignment 2 measurements and write experiment.csv (one row per run).
set -euo pipefail
cd "$(dirname "$0")"

OUT=experiment.csv
HW=hardware.txt
MAX_RANKS=5

{
    echo "cpu_model=$(lscpu | sed -n 's/^Model name:[[:space:]]*//p' | head -1)"
    echo "sockets=$(lscpu | sed -n 's/^Socket(s):[[:space:]]*//p' | head -1)"
    echo "cores_per_socket=$(lscpu | sed -n 's/^Core(s) per socket:[[:space:]]*//p' | head -1)"
    echo "threads_per_core=$(lscpu | sed -n 's/^Thread(s) per core:[[:space:]]*//p' | head -1)"
    echo "logical_cpus=$(lscpu | sed -n 's/^CPU(s):[[:space:]]*//p' | head -1)"
    echo "docker_nproc=$(nproc)"
} > "$HW"

header="program,p,run,TIME,BUSY_MIN,BUSY_MAX"
for r in $(seq 0 $((MAX_RANKS - 1))); do
    header="$header,rank${r}_messages,rank${r}_keys,rank${r}_busy"
done
echo "$header" > "$OUT"

blankRanks=$(printf ',,,%.0s' $(seq 1 $MAX_RANKS))

for run in $(seq 1 10); do
    echo "decryptSerial run $run" >&2
    ./decryptSerial experiment.txt words.txt >/dev/null 2>/tmp/a2.err
    time=$(sed -n 's/^TIME: //p' /tmp/a2.err)
    [ -n "$time" ] || { cat /tmp/a2.err >&2; exit 1; }
    echo "decryptSerial,,$run,$time,,$blankRanks" >> "$OUT"
done

for p in 2 3 5; do
    for run in $(seq 1 10); do
        echo "decryptParallel p=$p run $run" >&2
        mpiexec -n "$p" ./decryptParallel experiment.txt words.txt >/dev/null 2>/tmp/a2.err
        [ "$(grep -c '^RANK: ' /tmp/a2.err)" -eq "$p" ] || { cat /tmp/a2.err >&2; exit 1; }
        awk -v p="$p" -v run="$run" -v maxRanks="$MAX_RANKS" '
            $1 == "RANK:"     { cells[$2] = $4 "," $6 "," $8 }
            $1 == "BUSY_MIN:" { busyMin = $2 }
            $1 == "BUSY_MAX:" { busyMax = $2 }
            $1 == "TIME:"     { time = $2 }
            END {
                line = "decryptParallel," p "," run "," time "," busyMin "," busyMax
                for (r = 0; r < maxRanks; r++) {
                    line = line "," ((r in cells) ? cells[r] : ",,")
                }
                print line
            }
        ' /tmp/a2.err >> "$OUT"
    done
done

echo "wrote $OUT" >&2
