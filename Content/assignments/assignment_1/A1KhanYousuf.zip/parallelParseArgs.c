#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#include "parallelDependencies.h"

int parse_args(int argc, char **argv, ProgramArgs *out)
{
    char *end;
    long long n;
    long praw;
    unsigned long seed;

    if (argc != 5) {
        fprintf(stderr, "error: usage: %s <inputFile> <N> <p> <baseSeed>\n", argv[0]);
        return 1;
    }

    errno = 0;
    n = strtoll(argv[2], &end, 10);
    if (errno != 0 || end == argv[2] || *end != '\0' || n <= 0) {
        fprintf(stderr, "error: N must be an integer greater than 0\n");
        return 1;
    }

    errno = 0;
    praw = strtol(argv[3], &end, 10);
    if (errno != 0 || end == argv[3] || *end != '\0' || praw <= 0 || praw > INT_MAX) {
        fprintf(stderr, "error: p must be an integer greater than 0\n");
        return 1;
    }

    if (argv[4][0] == '-') {
        fprintf(stderr, "error: baseSeed must be an integer in 0..%u\n", UINT_MAX);
        return 1;
    }
    errno = 0;
    seed = strtoul(argv[4], &end, 10);
    if (errno != 0 || end == argv[4] || *end != '\0' || seed > UINT_MAX) {
        fprintf(stderr, "error: baseSeed must be an integer in 0..%u\n", UINT_MAX);
        return 1;
    }

    out->input_file = argv[1];
    out->num_samples = n;
    out->num_threads = (int)praw;
    out->base_seed = (unsigned int)seed;
    return 0;
}
