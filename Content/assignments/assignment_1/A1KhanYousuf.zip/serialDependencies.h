#ifndef DEPENDENCIES_H
#define DEPENDENCIES_H

typedef struct {
    const char *input_file;
    long long num_samples;
    unsigned int base_seed;
} ProgramArgs;

int parse_args(int argc, char **argv, ProgramArgs *out);

typedef struct {
    double x;
    double y;
    double r;
} Node;

typedef struct {
    double fieldWidth;
    double fieldHeight;
    int nodeCount;
    Node *nodes;
} Field;

int load_field(const char *filename, Field *out);

void print_field(const Field *field);

long long monte_carlo(const Field *field, long long n, unsigned int seed);

#endif
