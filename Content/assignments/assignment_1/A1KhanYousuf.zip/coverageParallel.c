#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <pthread.h>

#include "parallelDependencies.h"

// what fraction of the total area of the box is covered, using p threads

// ./coverageParallel <inputFile> <N> <p> <baseSeed>
int main(int argc, char **argv){

    // read command line arguments: inputFile, N, p, baseSeed
    ProgramArgs args;
    int status = parse_args(argc, argv, &args);
    if (status != 0) {
        return status;
    }
    int p = args.num_threads;

    // same loader as serial. field is read-only after this, so threads can share it
    Field field;
    status = load_field(args.input_file, &field);
    if (status != 0) {
        return status;
    }

    // split N across p threads
        // base = N / p, extra = N % p
        // thread i gets base samples, and the first extra threads get one more
        // thread i seed = baseSeed + i
        // each thread calls monte_carlo on its own count and its own seed
    long long base = args.num_samples / p;
    long long extra = args.num_samples % p;
    long long *counts = malloc((size_t)p * sizeof(long long));
    unsigned int *seeds = malloc((size_t)p * sizeof(unsigned int));
    long long *partial = malloc((size_t)p * sizeof(long long));
    pthread_t *threads = malloc((size_t)p * sizeof(pthread_t));
    Worker *workers = malloc((size_t)p * sizeof(Worker));
    if (counts == NULL || seeds == NULL || partial == NULL || threads == NULL || workers == NULL) {
        fprintf(stderr, "error: out of memory\n");
        free(counts);
        free(seeds);
        free(partial);
        free(threads);
        free(workers);
        free(field.nodes);
        return 1;
    }
    for (int i = 0; i < p; i++) {
        counts[i] = base + (i < extra);
        seeds[i] = args.base_seed + (unsigned int)i;
        workers[i].id = i;
        workers[i].thread_count = p;
        workers[i].field = &field;
        workers[i].count = counts[i];
        workers[i].seed = seeds[i];
        workers[i].partial = partial;
        workers[i].threads = threads;
    }

    // start timer here, before any pthread_create
    struct timespec start, stop;
    timespec_get(&start, TIME_UTC);

    // create p pthreads
        // each thread first does its own monte_carlo and stores the hit count in its own slot
        // only that thread writes its slot
        // higher ids first, so a parent never joins a thread that does not exist yet
    for (int i = p - 1; i >= 0; i--) {
        if (pthread_create(&threads[i], NULL, worker, &workers[i]) != 0) {
            fprintf(stderr, "error: pthread_create failed\n");
            exit(1);
        }
    }

    // tree reduction, done by those same threads, not by main adding every slot
        // stride = 1, 2, 4, ... while stride < p
        // thread i takes part in this round when i is a multiple of 2*stride
        // partner = i + stride
        // if partner < p: pthread_join that partner, then add partner's hits into i's slot
        // the join finishes the partner's own adds first, so the read is race-free
        // a thread with no partner this round keeps its sum and waits for its parent
        // thread 0 is the root and ends up with the total hits
        // main joins only thread 0
    pthread_join(threads[0], NULL);

    // stop timer after that final join
    timespec_get(&stop, TIME_UTC);

    // area = (hits / N) * fieldWidth * fieldHeight, percentage = (hits / N) * 100
    // stdout: SAMPLES, HITS, COVERAGE (%.1f area, %.6f percentage)
    // stderr: TIME:
    double seconds = (stop.tv_sec - start.tv_sec) + (stop.tv_nsec - start.tv_nsec) / 1e9;
    long long hits = partial[0];
    double fraction = (double)hits / (double)args.num_samples;
    double area = fraction * field.fieldWidth * field.fieldHeight;
    double percentage = fraction * 100.0;

    printf("SAMPLES: %lld\n", args.num_samples);
    printf("HITS: %lld\n", hits);
    printf("COVERAGE: %.1f %.6f\n", area, percentage);
    fprintf(stderr, "TIME: %.6f\n", seconds);

    free(counts);
    free(seeds);
    free(partial);
    free(threads);
    free(workers);
    free(field.nodes);
    return 0;
}
