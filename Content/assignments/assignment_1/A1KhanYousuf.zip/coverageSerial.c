#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "serialDependencies.h"

// what fraction of the total area of the box is covered!

// input_file, number-of_samples, base_seed
int main(int argc, char **argv){

    // read command line arguments: inputFile, N, baseSeed
    ProgramArgs args;
    int status = parse_args(argc, argv, &args);
    if (status != 0) {
        return status;
    }

    // load the file. unreadable or malformed file: error on stderr, nonzero exit
    Field field;
    status = load_field(args.input_file, &field);
    if (status != 0) {
        return status;
    }

    // seed stays outside the timer. rand_r updates this same variable inside monte_carlo
    unsigned int seed = args.base_seed;

    // start timer
    struct timespec start, stop;
    timespec_get(&start, TIME_UTC);

    // loop N times: random point in the field, count a hit if some node covers it
    long long hits = monte_carlo(&field, args.num_samples, seed);

    // stop timer
    timespec_get(&stop, TIME_UTC);

    // area = (hits / N) * fieldWidth * fieldHeight, percentage = (hits / N) * 100
    // stdout: SAMPLES, HITS, COVERAGE (%.1f area, %.6f percentage)
    // stderr: TIME:
    double seconds = (stop.tv_sec - start.tv_sec) + (stop.tv_nsec - start.tv_nsec) / 1e9;
    double fraction = (double)hits / (double)args.num_samples;
    double area = fraction * field.fieldWidth * field.fieldHeight;
    double percentage = fraction * 100.0;

    printf("SAMPLES: %lld\n", args.num_samples);
    printf("HITS: %lld\n", hits);
    printf("COVERAGE: %.1f %.6f\n", area, percentage);
    fprintf(stderr, "TIME: %.6f\n", seconds);


    free(field.nodes);
    return 0;
}