#!/bin/bash
# Run coverageParallel one process at a time and save every run to a CSV.
# Usage: ./run_batch.sh <runs> <cores> <inputFile> <N>
# Example: ./run_batch.sh 36 4 sample1.txt 100000000
# baseSeed for run k is 1000*k.
# Output: coverageParallelSample1_100000000_4.csv

if [ "$#" -ne 4 ]; then
    echo "usage: $0 <runs> <cores> <inputFile> <N>" >&2
    exit 1
fi

runs=$1
cores=$2
input=$3
n=$4

if [ ! -x ./coverageParallel ]; then
    echo "error: ./coverageParallel not found. Compile it first." >&2
    exit 1
fi

name=$(basename "$input" .txt)
sample=$(printf '%s' "$name" | tr -cd '0-9')
out="coverageParallel${name^}_${n}_${cores}.csv"

echo "program,sample,N,p,k,baseSeed,hits,coverage_pct,time_s" > "$out"

for ((k = 1; k <= runs; k++)); do
    seed=$((1000 * k))
    err=$(mktemp)
    if ! out_text=$(./coverageParallel "$input" "$n" "$cores" "$seed" 2>"$err"); then
        cat "$err" >&2
        rm -f "$err"
        exit 1
    fi

    hits=$(printf '%s\n' "$out_text" | awk '/^HITS:/ { print $2 }')
    coverage=$(printf '%s\n' "$out_text" | awk '/^COVERAGE:/ { print $3 }')
    seconds=$(awk '/^TIME:/ { print $2 }' "$err")
    rm -f "$err"

    if [ -z "$hits" ] || [ -z "$coverage" ] || [ -z "$seconds" ]; then
        echo "error: could not read HITS, COVERAGE, or TIME for k=$k" >&2
        exit 1
    fi

    echo "parallel,$sample,$n,$cores,$k,$seed,$hits,$coverage,$seconds" >> "$out"
    echo "parallel N=$n p=$cores k=$k time=$seconds"
done

echo "wrote $out"
