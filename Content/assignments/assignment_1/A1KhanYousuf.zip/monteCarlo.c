#define _POSIX_C_SOURCE 200809L

#include <stdlib.h>

#include "serialDependencies.h"

long long monte_carlo(const Field *field, long long n, unsigned int seed)
{
    long long hits = 0;
    long long i;

    for (i = 0; i < n; i++) {
        double x = (rand_r(&seed) / (RAND_MAX + 1.0)) * field->fieldWidth;
        double y = (rand_r(&seed) / (RAND_MAX + 1.0)) * field->fieldHeight;
        int j;

        for (j = 0; j < field->nodeCount; j++) {
            double dx = x - field->nodes[j].x;
            double dy = y - field->nodes[j].y;
            double r = field->nodes[j].r;

            if (dx * dx + dy * dy < r * r) {
                hits++;
                break;
            }
        }
    }
    return hits;
}
