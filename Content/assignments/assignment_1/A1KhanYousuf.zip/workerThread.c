#include "parallelDependencies.h"

void *worker(void *arg)
{
    Worker *w = arg;
    int stride;

    w->partial[w->id] = monte_carlo(w->field, w->count, w->seed);

    for (stride = 1; stride < w->thread_count; stride *= 2) {
        int partner;

        if (w->id % (2 * stride) != 0) {
            return NULL;
        }
        partner = w->id + stride;
        if (partner < w->thread_count) {
            pthread_join(w->threads[partner], NULL);
            w->partial[w->id] += w->partial[partner];
        }
    }
    return NULL;
}
