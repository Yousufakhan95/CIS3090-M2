#ifndef PARALLEL_DEPENDENCIES_H
#define PARALLEL_DEPENDENCIES_H

#include <pthread.h>

typedef struct {
    const char *input_file;
    long long num_samples;
    int num_threads;
    unsigned int base_seed;
} ProgramArgs;

int parse_args(int argc, char **argv, ProgramArgs *out);

typedef struct {
    double x;
    double y;
    double r;
} Node;

typedef struct {
    double fieldWidth;
    double fieldHeight;
    int nodeCount;
    Node *nodes;
} Field;

int load_field(const char *filename, Field *out);

long long monte_carlo(const Field *field, long long n, unsigned int seed);

typedef struct {
    int id;
    int thread_count;
    const Field *field;
    long long count;
    unsigned int seed;
    long long *partial;
    pthread_t *threads;
} Worker;

void *worker(void *arg);

#endif
