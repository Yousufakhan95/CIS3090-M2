#include <stdio.h>
#include <stdlib.h>

#include "serialDependencies.h"

int load_field(const char *filename, Field *out)
{
    FILE *fp;
    int k;
    int i;
    Node *nodes;

    fp = fopen(filename, "r");
    if (fp == NULL) {
        fprintf(stderr, "error: cannot read %s\n", filename);
        return 1;
    }

    if (fscanf(fp, "%lf %lf", &out->fieldWidth, &out->fieldHeight) != 2 ||
        out->fieldWidth <= 0 || out->fieldHeight <= 0) {
        fprintf(stderr, "error: malformed file\n");
        fclose(fp);
        return 1;
    }

    if (fscanf(fp, "%d", &k) != 1 || k < 0) {
        fprintf(stderr, "error: malformed file\n");
        fclose(fp);
        return 1;
    }

    nodes = NULL;
    if (k > 0) {
        nodes = malloc((size_t)k * sizeof(Node));
        if (nodes == NULL) {
            fprintf(stderr, "error: out of memory\n");
            fclose(fp);
            return 1;
        }
        for (i = 0; i < k; i++) {
            if (fscanf(fp, "%lf %lf %lf",
                       &nodes[i].x, &nodes[i].y, &nodes[i].r) != 3) {
                fprintf(stderr, "error: malformed file\n");
                free(nodes);
                fclose(fp);
                return 1;
            }
        }
    }

    fclose(fp);
    out->nodeCount = k;
    out->nodes = nodes;
    return 0;
}

void print_field(const Field *field)
{
    int i;

    printf("field: %.4f x %.4f\n", field->fieldWidth, field->fieldHeight);
    printf("nodes: %d\n", field->nodeCount);
    for (i = 0; i < field->nodeCount; i++) {
        printf("%d: %.4f %.4f %.4f\n", i,
               field->nodes[i].x, field->nodes[i].y, field->nodes[i].r);
    }
}
