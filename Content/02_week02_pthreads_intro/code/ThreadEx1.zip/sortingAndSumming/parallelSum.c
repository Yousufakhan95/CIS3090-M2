/* 
 Based on Advanced Programming in the Unix Environment, 3ed
 by R. Stevens and S. Rago
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

long nThr;                      /* number of threads */
long dataLen;                   /* number of numbers to sum */
long *thrDataLen;               /* number of elements to sum per thread */

double *nums;                     /* input data to sum */
double *partSums;                 /* partSums[i] -> thread i's partial sum */

void * threadFunction(void *arg);
double merge(void);
double calcTime(struct timespec start);
void invArgsExit(void);

typedef struct {
    long startOffset;
    long thrDataLen;
    int  myTid;
} threadArgs;

int main(int argc, char* argv[])
{
    pthread_t       *tid;
	unsigned long	i;
	struct timespec	start;
	double			elapsed;
	int				err;
	unsigned int	seed;

    if (argc == 1){
        //Defaults
        nThr = 1;
        dataLen = 64000000;
        seed = 1;
    }else if (argc == 3 || argc == 4){
        nThr = atol(argv[1]);
        dataLen = atol(argv[2]);
        seed = (argc == 4) ? (unsigned int) atol(argv[3]) : 1;
        if (nThr == 0 || dataLen == 0 ){
            invArgsExit();
        }
    }else{
        invArgsExit();
    }

    //Allocate the data buffers
    tid  = malloc(nThr*sizeof(pthread_t));
    partSums = malloc(nThr*sizeof(double));
    thrDataLen = malloc(nThr*sizeof(long));
    nums = malloc(dataLen*sizeof(double));
    
    //We do the even distribution
    
    //Every thread gets floor(dataLen/nThr) data points
    for (int i = 0; i < nThr; i++){
        thrDataLen[i] = dataLen/nThr;
    }

    /* 
     * dataLen may not divide evenly; hand out the dataLen % nThr
     * leftover points one at a time to the first few threads
     */
    long dataCount = (dataLen/nThr) * nThr;
    i = 0;
    while (dataCount < dataLen){
        thrDataLen[i] += 1;
        dataCount += 1;
        i += 1;
    }
    
	/*
	 * Create the initial set of numbers to sum.
	 */
	srandom(seed);
    for (i = 0; i < dataLen; i++){
        //We keep the individual numbers small to avoid potential overflows
		nums[i] = random() % 10;
    }

    /*
     * Get timing data
     */
	clock_gettime(CLOCK_MONOTONIC, &start);
    
    /*
     * Create NTHR threads to sum the numbers.
     */

    threadArgs *tArgs;
    long currOffset = 0;
    for (i = 0; i < nThr; i++) {
        /* Each thread sums its own contiguous slice of nums[],
         * starting at currOffset and covering thrDataLen[i] elements
         */
        tArgs = malloc(sizeof(threadArgs));
        tArgs->startOffset = currOffset;
        tArgs->thrDataLen = thrDataLen[i];
        tArgs->myTid = i;
        err = pthread_create(&tid[i], NULL, threadFunction, (void *)tArgs);
        if (err != 0){
            printf("Cannot create thread, error: %d", err);
            exit(-1);
        }
        currOffset += thrDataLen[i];
    }
    
    /*
     * Wait for workers to finish and merge the sums
     */
    
    for (int i = 0; i < nThr; i++){
        pthread_join(tid[i], NULL);
    }
    double sum = merge();
    
    /*
     * Get and display elapsed time
     */
    elapsed = calcTime(start);
    fprintf(stderr, "TIME:%.4f\n", elapsed);
    fprintf(stderr, "SUM:%.4f\n", sum);

    free(tid);
    free(thrDataLen);
    free(nums);
    free(partSums);

	exit(0);
}

/*
 * Worker thread: sums its own slice of nums[] into partSums[myTid].
 * Each thread only touches its own slot, so there's no shared-data
 * race to worry about.
 */
void * threadFunction(void *arg)
{
    threadArgs	*tArgs = (threadArgs*)arg;
    partSums[tArgs->myTid] = 0;
    for (long i = tArgs->startOffset; i < tArgs->startOffset+tArgs->thrDataLen; i++){
        partSums[tArgs->myTid] += nums[i];
    }
    
    free(tArgs);
    return((void *)0);
}

/*
 * Add together each thread's partial sum into a single total.
 */
double merge(void)
{
    double  sum = 0;
    
    for (int threadID = 0; threadID < nThr; threadID++) {
        sum += partSums[threadID];
    }

    return sum;
}

double calcTime(struct timespec start){
    
    struct timespec end;
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

void invArgsExit(void){
    fprintf(stderr, "Incorrect number of arguments\n");
    fprintf(stderr, "Usage: <exec_name> or <exec_name> nThreads dataLen [seed].\n");
    fprintf(stderr, "If nThreads and dataLen are provided, they must be positive integers.\n");
    fprintf(stderr, "Exiting...\n");
    exit(1);
}
