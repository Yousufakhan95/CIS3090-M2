/* oddEvenParallel.c
 *
 * Parallel odd-even transposition sort using Pthreads, based on the
 * algorithm in Pacheco & Malensek, "An Introduction to Parallel
 * Programming", 2nd ed., Section 3.7.
 *
 * Unlike Pacheco's code, our keys (sorted data) are doubles, 
 * not ints.
 *
 * Build:   make
 * Run:     ./oddEvenParallel <threadCount> <n> [seed]
 *          n must be evenly divisible by threadCount.
 */

/*
 * pthread_barrier_t is POSIX, not plain standard C - glibc hides it under
 * -std=c99 unless this is defined first. 
 * _DEFAULT_SOURCE is also needed here: _POSIX_C_SOURCE alone turns off glibc's default
 * extensions, and random()/srandom() live in that extension set. 
 */
#define _POSIX_C_SOURCE 200809L
#define _DEFAULT_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

int threadCount;
int localN;                    /* n / threadCount: keys per thread */
double **myKeys;               /* myKeys[i] -> thread i's block */
double **tempKeys;             /* tempKeys[i] -> scratch space for i */
pthread_barrier_t barrier;

int compareDoubles(const void *a, const void *b);
double calcTime(struct timespec start);
int computePartner(int phase, int threadId);
void mergeLow(double myKeys[], double recvKeys[], double tempKeys[], int n);
void mergeHigh(double myKeys[], double recvKeys[], double tempKeys[], int n);
void *oddEvenThread(void *arg);

int main(int argc, char *argv[]) {
    int n, i;
    double *allKeys;
    pthread_t *threads;
    unsigned int seed;
    struct timespec	start;
    
    if (argc < 3) {
        fprintf(stderr, "Usage: %s <threadCount> <n> [seed]\n", argv[0]);
        fprintf(stderr, "       n must be evenly divisible by threadCount\n");
        return 1;
    }

    threadCount = atoi(argv[1]);
    n = atoi(argv[2]);
    seed = (argc > 3) ? (unsigned int) atoi(argv[3]) : 1;

    if (threadCount < 1 || n < 1 || n % threadCount != 0) {
        fprintf(stderr, "Error: need threadCount >= 1, n >= 1, "
                        "and n divisible by threadCount.\n");
        return 1;
    }
    localN = n / threadCount;

    /*
     * Get timing data
     */
	clock_gettime(CLOCK_MONOTONIC, &start);

    /*
     * One contiguous array; each thread's block is a slice, so the
     * final result lines up sorted end-to-end with no extra copying.
    */
    allKeys = malloc(n * sizeof(double));
    myKeys   = malloc(threadCount * sizeof(double *));
    tempKeys = malloc(threadCount * sizeof(double *));
    threads  = malloc(threadCount * sizeof(pthread_t));

    /*
     * Note: we use the same randome number seeding/generation as 
     * as parallelSort.c, so the two examples sort comparable data.
     */
    srandom(seed);
    for (i = 0; i < n; i++)
        allKeys[i] = random();

    for (i = 0; i < threadCount; i++) {
        myKeys[i]   = &allKeys[i * localN];
        tempKeys[i] = malloc(localN * sizeof(double));
    }

    pthread_barrier_init(&barrier, NULL, threadCount);

    for (i = 0; i < threadCount; i++)
        pthread_create(&threads[i], NULL, oddEvenThread, (void *) (long) i);
    for (i = 0; i < threadCount; i++)
        pthread_join(threads[i], NULL);

    /*
     * Get and display elapsed time
     */
    double elapsed = calcTime(start);
    fprintf(stderr, "TIME:%.4f\n", elapsed);

    /*
     * Optional testing hook: if DUMP_FILE is set, write the sorted
     * array to that path as raw doubles, for external correctness
     * checking. Runs after calcTime(), so we don't affect the timing.
     * Same as the serialSort.c example
     */
    const char *dumpPath = getenv("DUMP_FILE");
    if (dumpPath) {
        FILE *f = fopen(dumpPath, "wb");
        if (f) {
            fwrite(allKeys, sizeof(double), n, f);
            fclose(f);
        }
    }

    pthread_barrier_destroy(&barrier);
    for (i = 0; i < threadCount; i++)
        free(tempKeys[i]);
    free(tempKeys);
    free(myKeys);
    free(threads);
    free(allKeys);

    return 0;
}

int compareDoubles(const void *a, const void *b) {
    double valA = *(const double *) a;
    double valB = *(const double *) b;
    if (valA < valB) return -1;
    if (valA > valB) return 1;
    return 0;
}

double calcTime(struct timespec start){
    
    struct timespec end;
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

/*
 * For a given phase, decides which thread this thread should pair up
 * with. Returns -1 if this thread sits out the phase.
 */
int computePartner(int phase, int threadId) {
    int partner;

    if (phase % 2 == 0) {              /* Even phase */
        if (threadId % 2 != 0)          /* Odd threadId  */
            partner = threadId - 1;
        else                            /* Even threadId */
            partner = threadId + 1;
    } else {                           /* Odd phase  */
        if (threadId % 2 != 0)          /* Odd threadId  */
            partner = threadId + 1;
        else                            /* Even threadId */
            partner = threadId - 1;
    }

    if (partner == -1 || partner == threadCount)
        partner = -1;   /* No partner this phase: stay idle */

    return partner;
}

//Pacheco Program 3.16: merge the smallest n keys of myKeys+recvKeys into tempKeys.
void mergeLow(double myKeys[], double recvKeys[], double tempKeys[], int n) {
    int mIdx = 0, rIdx = 0, tIdx = 0;

    while (tIdx < n) {
        if (myKeys[mIdx] <= recvKeys[rIdx]) {
            tempKeys[tIdx] = myKeys[mIdx];
            tIdx++; mIdx++;
        } else {
            tempKeys[tIdx] = recvKeys[rIdx];
            tIdx++; rIdx++;
        }
    }
}

//Mirror of mergeLow: keeps the largest n keys, built from the top down.
void mergeHigh(double myKeys[], double recvKeys[], double tempKeys[], int n) {
    int mIdx = n - 1, rIdx = n - 1, tIdx = n - 1;

    while (tIdx >= 0) {
        if (myKeys[mIdx] >= recvKeys[rIdx]) {
            tempKeys[tIdx] = myKeys[mIdx];
            tIdx--; mIdx--;
        } else {
            tempKeys[tIdx] = recvKeys[rIdx];
            tIdx--; rIdx--;
        }
    }
}

//Each thread runs this once, for its entire lifetime.
void *oddEvenThread(void *arg) {
    long threadId = (long) arg;
    int phase, partner, i;

    qsort(myKeys[threadId], localN, sizeof(double), compareDoubles);

    for (phase = 0; phase < threadCount; phase++) {
        partner = computePartner(phase, threadId);

        //Barrier 1: wait until every thread finished writing last phase's result
        pthread_barrier_wait(&barrier);

        if (partner != -1) {
            //Partner's block lives in the same shared array - read it directly
            if (threadId < partner)
                mergeLow(myKeys[threadId], myKeys[partner],
                        tempKeys[threadId], localN);
            else
                mergeHigh(myKeys[threadId], myKeys[partner],
                        tempKeys[threadId], localN);
        }

        //Barrier 2: wait until every reader is done before overwriting this block
        pthread_barrier_wait(&barrier);

        if (partner != -1) {
            for (i = 0; i < localN; i++)
                myKeys[threadId][i] = tempKeys[threadId][i];
        }
    }

   return NULL;
}