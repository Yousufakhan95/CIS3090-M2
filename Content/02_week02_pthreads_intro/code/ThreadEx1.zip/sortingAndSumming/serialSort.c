/* 
 Based on Advanced Programming in the Unix Environment, 3ed
 by R. Stevens and S. Rago
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int compareDoubles(const void *arg1, const void *arg2);
double calcTime(struct timespec start);
void invArgsExit(void);

int main(int argc, char* argv[])
{
	long            dataLen;
	struct timespec	start;
	double			elapsed;
    double*         nums;
    unsigned int    seed;

    if (argc == 1){
        dataLen = 64000000;
        seed = 1;
    }else if (argc == 2 || argc == 3){
        dataLen = atol(argv[1]);
        seed = (argc == 3) ? (unsigned int) atol(argv[2]) : 1;
        if (dataLen == 0 ){
            invArgsExit();
        }
    }else{
        invArgsExit();
    }

    //Allocate the data buffer
    nums = malloc(dataLen*sizeof(double));

	/*
	 * Create the initial set of numbers to sort.
	 */
	srandom(seed);
    for (int i = 0; i < dataLen; i++){
		nums[i] = random();
    }

    /*
     * Get timing data
     */
	clock_gettime(CLOCK_MONOTONIC, &start);
    
    /*
     * Do serial sort
     */
    qsort(nums, dataLen, sizeof(double), compareDoubles);

    /*
     * Get and display elapsed time
     */
    elapsed = calcTime(start);
    fprintf(stderr, "TIME:%.4f\n", elapsed);

    /*
     * Optional testing hook: if DUMP_FILE is set, write the sorted
     * array to that path as raw doubles, for external correctness
     * checking. Runs after calcTime(), so we don't affect the timing.
     */
    const char *dumpPath = getenv("DUMP_FILE");
    if (dumpPath) {
        FILE *f = fopen(dumpPath, "wb");
        if (f) {
            fwrite(nums, sizeof(double), dataLen, f);
            fclose(f);
        }
    }

    free(nums);

	exit(0);
}

int compareDoubles(const void *arg1, const void *arg2)
{
    double l1 = *(double *)arg1;
    double l2 = *(double *)arg2;
    
    if (l1 == l2)
        return 0;
    else if (l1 < l2)
        return -1;
    else
        return 1;
}

double calcTime(struct timespec start){
    
    struct timespec end;
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

void invArgsExit(void){
    fprintf(stderr, "Incorrect number of arguments\n");
    fprintf(stderr, "Usage: <exec_name> or <exec_name> dataLen [seed].\n");
    fprintf(stderr, "If dataLen is provided, it must be a positive integer.\n");
    fprintf(stderr, "Exiting...\n");
    exit(1);
}
