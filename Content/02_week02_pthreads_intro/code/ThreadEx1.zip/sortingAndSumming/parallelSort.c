/* 
 Based on Advanced Programming in the Unix Environment, 3ed
 by R. Stevens and S. Rago
 */

#include <float.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

long nThr;                      /* number of threads */
long dataLen;                   /* number of numbers to sort */
long *thrDataLen;               /* number of elements to sort per thread */

double *nums;                     /* unsorted data, sorted in place per-thread */
double *snums;                    /* final sorted output, built by merge() */

int compareDoubles(const void *arg1, const void *arg2);
void * threadFunction(void *arg);
void merge(void);
double calcTime(struct timespec start);
void invArgsExit(void);

typedef struct {
    long startOffset;
    long thrDataLen;
    int  myTid;
} threadArgs;

int main(int argc, char* argv[])
{
    pthread_t       *tid;
	unsigned long	i;
	struct timespec	start;
	double			elapsed;
	int				err;
	unsigned int	seed;

    if (argc == 1){
        //Defaults
        nThr = 1;
        dataLen = 64000000;
        seed = 1;
    }else if (argc == 3 || argc == 4){
        nThr = atol(argv[1]);
        dataLen = atol(argv[2]);
        seed = (argc == 4) ? (unsigned int) atol(argv[3]) : 1;
        if (nThr == 0 || dataLen == 0 ){
            invArgsExit();
        }
    }else{
        invArgsExit();
    }
    
    //Allocate the data buffers
    tid  = malloc(nThr*sizeof(pthread_t));
    thrDataLen = malloc(nThr*sizeof(long));
    nums = malloc(dataLen*sizeof(double));
    snums = malloc(dataLen*sizeof(double));
    
    //We do the even distribution
    
    //Every thread gets floor(dataLen/nThr) data points
    for (int i = 0; i < nThr; i++){
        thrDataLen[i] = dataLen/nThr;
    }

    /*
     * dataLen may not divide evenly; hand out the dataLen % nThr
     * leftover points one at a time to the first few threads
     */
    long dataCount = (dataLen/nThr) * nThr;
    i = 0;
    while (dataCount < dataLen){
        thrDataLen[i] += 1;
        dataCount += 1;
        i += 1;
    }
    
	/*
	 * Create the initial set of numbers to sort.
	 */
	srandom(seed);
    for (i = 0; i < dataLen; i++){
		nums[i] = random();
    }

    /*
     * Get timing data
     */
	clock_gettime(CLOCK_MONOTONIC, &start);
    
    /*
     * Create NTHR threads to sort the numbers.
     */

    threadArgs *tArgs;
    long currOffset = 0;
    for (i = 0; i < nThr; i++) {
        /*
         * Each thread sorts its own contiguous slice of nums[],
         * starting at currOffset and covering thrDataLen[i] elements
         */
        tArgs = malloc(sizeof(threadArgs));
        tArgs->startOffset = currOffset;
        tArgs->thrDataLen = thrDataLen[i];
        tArgs->myTid = i;
        err = pthread_create(&tid[i], NULL, threadFunction, (void *)tArgs);
        if (err != 0){
            printf("Cannot create thread, error: %d", err);
            exit(-1);
        }
        currOffset += thrDataLen[i];
    }
    
    /*
     * Wait for workers to finish and merge the sorted sub-arrays
     */
    
    for (int i = 0; i < nThr; i++){
        pthread_join(tid[i], NULL);
    }
    merge();
    
    /*
     * Get and display elapsed wall time
     */
    elapsed = calcTime(start);
    fprintf(stderr, "TIME:%.4f\n", elapsed);

    /* 
     * Optional testing hook: if DUMP_FILE is set, write the sorted
     * array to that path as raw doubles, for external correctness
     * checking. No effect on timing - runs after calcTime().
     */
    const char *dumpPath = getenv("DUMP_FILE");
    if (dumpPath) {
        FILE *f = fopen(dumpPath, "wb");
        if (f) {
            fwrite(snums, sizeof(double), dataLen, f);
            fclose(f);
        }
    }

    free(tid);
    free(thrDataLen);
    free(nums);
    free(snums);

	exit(0);
}

int compareDoubles(const void *arg1, const void *arg2)
{
    double l1 = *(double *)arg1;
    double l2 = *(double *)arg2;
    
    if (l1 == l2)
        return 0;
    else if (l1 < l2)
        return -1;
    else
        return 1;
}

/*
 * Worker thread: sorts its own slice of nums[] in place with qsort.
 * No merging happens here - each thread only ever touches its own
 * slice, so there's no shared-data race to worry about.
 */
void * threadFunction(void *arg)
{
    threadArgs	*tArgs = (threadArgs*)arg;
    qsort(&nums[tArgs->startOffset], tArgs->thrDataLen, sizeof(double), compareDoubles);
    free(tArgs);
    return((void *)0);
}

/*
 * Merge the nThr sorted sub-arrays (each already sorted in place by
 * threadFunction) into snums[]. 
 */
void merge(void)
{
    long	*threadOffset = malloc(nThr * sizeof(long));
    long	*threadEnd = malloc(nThr * sizeof(long));
    
    threadOffset[0] = 0;
    threadEnd[0] = thrDataLen[0]-1;
    for (int i = 1; i < nThr; i++){
        threadOffset[i] = thrDataLen[i-1] + threadOffset[i-1];
        threadEnd[i] = threadOffset[i] + thrDataLen[i]-1;
    }
    
    for (long sindex = 0; sindex < dataLen; sindex++) {
        double minVal = DBL_MAX;
        int minThrIndex = 0;
        for (int threadID = 0; threadID < nThr; threadID++) {
            //Find the smallest value in the current postions of sorted sub-arrays
            //Do not exceed the sub-array boundaries
            long currOffset = threadOffset[threadID];
            long currEnd = threadEnd[threadID];
            if ( currOffset <= currEnd && nums[currOffset] < minVal ){
                minVal = nums[currOffset];
                minThrIndex = threadID;
            }
        }
        //Store the min value
        snums[sindex] = nums[threadOffset[minThrIndex]];
        //Increment the start offset for the sub-array where the min value was
        threadOffset[minThrIndex] += 1;
    }

    free(threadOffset);
    free(threadEnd);
}

double calcTime(struct timespec start){
    
    struct timespec end;
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

void invArgsExit(void){
    fprintf(stderr, "Incorrect number of arguments\n");
    fprintf(stderr, "Usage: <exec_name> or <exec_name> nThreads dataLen [seed].\n");
    fprintf(stderr, "If nThreads and dataLen are provided, they must be positive integers.\n");
    fprintf(stderr, "Exiting...\n");
    exit(1);
}
