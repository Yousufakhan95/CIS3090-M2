/* oddEvenSerial.c
 *
 * Serial odd-even transposition sort, matching the algorithm in
 * Pacheco & Malensek's serial Odd_even_sort pseudocode (Ch. 3):
 *
 * Unlike Pacheco's code, our keys (sorted data) are doubles, 
 * not ints.
 *
 *
 * Build:   make
 * Run:     ./oddEvenSerial <n> [seed]
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double calcTime(struct timespec start);
void invArgsExit(void);

int main(int argc, char* argv[])
{
    long            n;
    double*         keys;
    struct timespec start;
    double          elapsed;
    unsigned int    seed;

    if (argc == 1){
        n = 20000;
        seed = 1;
    }else if (argc == 2 || argc == 3){
        n = atol(argv[1]);
        seed = (argc == 3) ? (unsigned int) atol(argv[2]) : 1;
        if (n == 0){
            invArgsExit();
        }
    }else{
        invArgsExit();
    }

    //Allocate the data buffer
    keys = malloc(n * sizeof(double));

    /*
     * Create the initial set of numbers to sort.
     */
    srandom(seed);
    for (long i = 0; i < n; i++)
        keys[i] = random();

    /*
     * Get timing data
     */
    clock_gettime(CLOCK_MONOTONIC, &start);

    /*
     * n phases: even phases compare-swap (0,1),(2,3),...;
     * odd phases compare-swap (1,2),(3,4),...
     */
    for (long phase = 0; phase < n; phase++) {
        long startIdx = (phase % 2 == 0) ? 0 : 1;
        for (long i = startIdx; i + 1 < n; i += 2) {
            if (keys[i] > keys[i+1]) {
                double tmp = keys[i];
                keys[i] = keys[i+1];
                keys[i+1] = tmp;
            }
        }
    }

    /*
     * Get and display elapsed time
     */
    elapsed = calcTime(start);
    fprintf(stderr, "TIME:%.4f\n", elapsed);

    /*
     * Optional testing hook: if DUMP_FILE is set, write the sorted
     * array to that path as raw doubles, for external correctness
     * checking. Runs after calcTime(), so we don't affect the timing.
     * Same as the serialSort.c example
     */
    const char *dumpPath = getenv("DUMP_FILE");
    if (dumpPath) {
        FILE *f = fopen(dumpPath, "wb");
        if (f) {
            fwrite(keys, sizeof(double), n, f);
            fclose(f);
        }
    }

    free(keys);

    exit(0);
}

double calcTime(struct timespec start){
    
    struct timespec end;
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

void invArgsExit(void){
    fprintf(stderr, "Incorrect number of arguments\n");
    fprintf(stderr, "Usage: <exec_name> or <exec_name> n [seed].\n");
    fprintf(stderr, "If n is provided, it must be a positive integer.\n");
    fprintf(stderr, "Exiting...\n");
    exit(1);
}
