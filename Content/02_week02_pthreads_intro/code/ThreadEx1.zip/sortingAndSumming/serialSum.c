/* 
 Based on Advanced Programming in the Unix Environment, 3ed
 by R. Stevens and S. Rago
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

double calcTime(struct timespec start);
void invArgsExit(void);

int main(int argc, char* argv[])
{
    long            dataLen;        /* number of numbers to sum */
	unsigned long	i;
	struct timespec	start;
	double			elapsed;
    double			sum;
    double*         nums;
    unsigned int    seed;

    if (argc == 1){
        //Defaults
        dataLen = 64000000;
        seed = 1;
    }else if (argc == 2 || argc == 3){
        dataLen = atol(argv[1]);
        seed = (argc == 3) ? (unsigned int) atol(argv[2]) : 1;
        if (dataLen == 0 ){
            invArgsExit();
        }
    }else{
        invArgsExit();
    }
    
    //Allocate the data buffer
    nums = malloc(dataLen*sizeof(double));
    
	/*
	 * Create the initial set of numbers to sum.
	 */
	srandom(seed);
    for (i = 0; i < dataLen; i++){
        //We keep the individual numbers small to avoid potential overflows
		nums[i] = random() % 10;
    }

    /*
     * Get timing data
     */
	clock_gettime(CLOCK_MONOTONIC, &start);
    
    sum = 0;
    for (i = 0; i < dataLen; i++){
        sum += nums[i];
    }

    elapsed = calcTime(start);
    fprintf(stderr, "TIME:%.4f\n", elapsed);
    fprintf(stderr, "SUM:%.4f\n", sum);

    free(nums);

	exit(0);
}

double calcTime(struct timespec start){
    
    struct timespec end;
    
    clock_gettime(CLOCK_MONOTONIC, &end);
    
    return (double)(end.tv_sec - start.tv_sec) + (double)(end.tv_nsec - start.tv_nsec) / 1e9;
}

void invArgsExit(void){
    fprintf(stderr, "Incorrect number of arguments\n");
    fprintf(stderr, "Usage: <exec_name> or <exec_name> dataLen [seed].\n");
    fprintf(stderr, "If dataLen is provided, it must be a positive integer.\n");
    fprintf(stderr, "Exiting...\n");
    exit(1);
}
