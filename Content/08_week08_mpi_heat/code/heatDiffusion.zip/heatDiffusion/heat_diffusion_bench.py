#!/usr/bin/env python3
"""
heat_diffusion_bench.py

Benchmarking harness for the MPI heat diffusion case study (MPI only --
see MPI_Heat_Diffusion_Design_Decisions.md; a combined Pthreads/MPI
comparison was considered and deferred). Sweeps rank count, repeats each
configuration REPEATS times, and writes a CSV of wall time plus the four
instrumented phase times (compute, halo exchange, allreduce, output) that
heat_diffusion_mpi prints in its summary line.

Frame output is suppressed during benchmarking by passing a frame_stride
larger than max_iters. This costs nothing in the binary itself (the write
is gated on iteration % frame_stride == 0, and frame 0 is always written
once regardless of stride -- negligible overhead), and it avoids ~29 MB of
PGMs per run hitting disk REPEATS x len(RANK_COUNTS) times.

Usage:
    python3 heat_diffusion_bench.py [binary] [outfile.csv]

Defaults: binary="./heat_diffusion_mpi", outfile="heat_diffusion_mpi_bench.csv"

Edit RANK_COUNTS below to match the number of cores actually available in
your container -- this is not auto-detected, since oversubscription
behaviour (and whether --oversubscribe is needed) varies by machine and is
a grading-environment concern, not a benchmarking-harness one.
"""

import csv
import re
import subprocess
import sys

REPEATS = 30
RANK_COUNTS = [1, 2, 4, 8]  # edit to match available cores

# Simulation parameters -- match the frozen case-study defaults in
# heat_diffusion_mpi.c. frame_stride is overridden here to suppress output.
N = 514
K = 96
EPSILON = 1e-4
MAX_ITERS = 50000
FRAME_STRIDE = MAX_ITERS + 1
OUTDIR = "/tmp/heat_diffusion_bench_frames"

SUMMARY_RE = re.compile(
    r"N=(\d+) ranks=(\d+) K=(\d+) eps=([\d.eE+-]+) -> (\d+) iterations, "
    r"([\d.]+) sec, (\d+) frames"
)
PHASE_RE = re.compile(
    r"compute=([\d.]+) comm=([\d.]+) allreduce=([\d.]+) output=([\d.]+)"
)


def run_once(binary, ranks):
    cmd = [
        "mpirun", "-np", str(ranks), binary,
        str(N), str(K), str(EPSILON), str(MAX_ITERS), str(FRAME_STRIDE), OUTDIR,
    ]
    result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    return result.stdout


def parse_output(stdout, ranks):
    summary = SUMMARY_RE.search(stdout)
    phases = PHASE_RE.search(stdout)
    if not summary or not phases:
        raise RuntimeError(f"could not parse output for ranks={ranks}:\n{stdout}")
    return {
        "ranks": ranks,
        "iterations": int(summary.group(5)),
        "wall_sec": float(summary.group(6)),
        "compute_sec": float(phases.group(1)),
        "comm_sec": float(phases.group(2)),
        "allreduce_sec": float(phases.group(3)),
        "output_sec": float(phases.group(4)),
    }


def main():
    binary = sys.argv[1] if len(sys.argv) > 1 else "./heat_diffusion_mpi"
    outfile = sys.argv[2] if len(sys.argv) > 2 else "heat_diffusion_mpi_bench.csv"

    rows = []
    for ranks in RANK_COUNTS:
        print(f"ranks={ranks}: ", end="", flush=True)
        for run_idx in range(REPEATS):
            stdout = run_once(binary, ranks)
            row = parse_output(stdout, ranks)
            row["run"] = run_idx
            rows.append(row)
            print(".", end="", flush=True)
        print()

    fieldnames = [
        "ranks", "run", "iterations", "wall_sec",
        "compute_sec", "comm_sec", "allreduce_sec", "output_sec",
    ]
    with open(outfile, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    print(f"Wrote {len(rows)} rows -> {outfile}")


if __name__ == "__main__":
    main()
