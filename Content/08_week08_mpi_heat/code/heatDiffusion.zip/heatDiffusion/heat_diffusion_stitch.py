#!/usr/bin/env python3
"""
heat_diffusion_stitch.py

Colorizes raw PGM frames from the heat diffusion case study (Pthreads, and
later MPI/Warp -- same PGM format, same script) and stitches them into an
animated GIF.

This example uses only the Pillow library installed in the CIS*2750 Docker container.

A GIF's palette holds exactly 256 colors, and the "hot"
colormap below (black -> red -> yellow -> white) maps each of the 256
possible grayscale intensities in a PGM byte to exactly one fixed RGB
triple. Each frame's raw byte values are reinterpreted directly as palette 
indices (Pillow mode "P"), with no RGB conversion or color quantization step 
in between.

Usage:
    python3 heat_diffusion_stitch.py [frames_dir] [output.gif] [ms_per_frame]

Defaults: frames_dir="frames", output.gif="heat_diffusion.gif", ms_per_frame=80
"""

import sys
import glob
import os
from PIL import Image


def make_hot_palette():
    """Build a 768-entry flat palette (256 x RGB): black -> red -> yellow -> white.

    Three equal segments, each a straight ramp of one channel:
      [0,   1/3): black -> red     (R ramps up)
      [1/3, 2/3): red   -> yellow  (G ramps up)
      [2/3, 1]:   yellow-> white   (B ramps up)
    """
    palette = []
    for i in range(256):
        t = i / 255.0
        if t < 1 / 3:
            r = int(255 * (t / (1 / 3)))
            g = 0
            b = 0
        elif t < 2 / 3:
            r = 255
            g = int(255 * ((t - 1 / 3) / (1 / 3)))
            b = 0
        else:
            r = 255
            g = 255
            b = int(255 * ((t - 2 / 3) / (1 / 3)))
        palette.extend([r, g, b])
    return palette


def colorize_frame(pgm_path, palette):
    """Load a grayscale PGM and reinterpret its byte values as palette indices.

    This is NOT the usual convert("L") -> convert("P") path, which would
    quantize colors. Here the palette is built so that index i IS the
    color for original gray level i, so we just relabel the existing data.
    """
    gray = Image.open(pgm_path).convert("L")
    indexed = Image.new("P", gray.size)
    indexed.putpalette(palette)
    # indexed.putdata(list(gray.getdata()))
    indexed.putdata(gray.get_flattened_data())
    return indexed


def main():
    frames_dir = sys.argv[1] if len(sys.argv) > 1 else "frames"
    out_path = sys.argv[2] if len(sys.argv) > 2 else "heat_diffusion.gif"
    ms_per_frame = int(sys.argv[3]) if len(sys.argv) > 3 else 80

    frame_paths = sorted(glob.glob(os.path.join(frames_dir, "frame_*.pgm")))
    if not frame_paths:
        print(f"No frames found in {frames_dir}/ (expected frame_*.pgm)", file=sys.stderr)
        sys.exit(1)

    palette = make_hot_palette()
    frames = [colorize_frame(p, palette) for p in frame_paths]

    # Hold the final (converged) frame longer so it reads as "done" rather
    # than looping abruptly mid-motion.
    durations = [ms_per_frame] * len(frames)
    durations[-1] = ms_per_frame * 15

    frames[0].save(
        out_path,
        save_all=True,
        append_images=frames[1:],
        duration=durations,
        loop=0,
        optimize=False,  # keep our exact palette -- don't let Pillow re-quantize it
    )

    size_mb = os.path.getsize(out_path) / 1e6
    print(f"Wrote {len(frames)} frames -> {out_path} ({size_mb:.1f} MB)")


if __name__ == "__main__":
    main()
